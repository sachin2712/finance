(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var TypeScript = Package['barbatus:typescript-compiler'].TypeScript;
var TypeScriptCompiler = Package['barbatus:typescript-compiler'].TypeScriptCompiler;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['barbatus:typescript'] = {};

})();
