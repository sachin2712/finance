(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var UploadFS;

var require = meteorInstall({"node_modules":{"meteor":{"jalik:ufs":{"ufs.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/meteor","meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var stores = {};                                                                                                       // 5
                                                                                                                       //
UploadFS = {                                                                                                           // 7
                                                                                                                       //
    /**                                                                                                                //
     * Contains all stores                                                                                             //
     */                                                                                                                //
    store: {},                                                                                                         // 12
                                                                                                                       //
    /**                                                                                                                //
     * Collection of tokens                                                                                            //
     */                                                                                                                //
    tokens: new Mongo.Collection('ufsTokens'),                                                                         // 17
                                                                                                                       //
    /**                                                                                                                //
     * Returns the store by its name                                                                                   //
     * @param name                                                                                                     //
     * @return {UploadFS.Store}                                                                                        //
     */                                                                                                                //
    getStore: function getStore(name) {                                                                                // 24
        return stores[name];                                                                                           // 25
    },                                                                                                                 // 26
                                                                                                                       //
    /**                                                                                                                //
     * Returns all stores                                                                                              //
     * @return {object}                                                                                                //
     */                                                                                                                //
    getStores: function getStores() {                                                                                  // 32
        return stores;                                                                                                 // 33
    },                                                                                                                 // 34
                                                                                                                       //
    /**                                                                                                                //
     * Returns the temporary file path                                                                                 //
     * @param fileId                                                                                                   //
     * @return {string}                                                                                                //
     */                                                                                                                //
    getTempFilePath: function getTempFilePath(fileId) {                                                                // 41
        return UploadFS.config.tmpDir + '/' + fileId;                                                                  // 42
    },                                                                                                                 // 43
                                                                                                                       //
    /**                                                                                                                //
     * Imports a file from a URL                                                                                       //
     * @param url                                                                                                      //
     * @param file                                                                                                     //
     * @param store                                                                                                    //
     * @param callback                                                                                                 //
     */                                                                                                                //
    importFromURL: function importFromURL(url, file, store, callback) {                                                // 52
        if (typeof store === 'string') {                                                                               // 53
            Meteor.call('ufsImportURL', url, file, store, callback);                                                   // 54
        } else if ((typeof store === 'undefined' ? 'undefined' : _typeof(store)) === 'object') {                       // 55
            store.importFromURL(url, file, callback);                                                                  // 57
        }                                                                                                              // 58
    }                                                                                                                  // 59
};                                                                                                                     // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-mime.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-mime.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    //
 * MIME types and extensions                                                                                           //
 */                                                                                                                    //
var MIME = {                                                                                                           // 4
                                                                                                                       //
    // application                                                                                                     //
    '7z': 'application/x-7z-compressed',                                                                               // 7
    'arc': 'application/octet-stream',                                                                                 // 8
    'ai': 'application/postscript',                                                                                    // 9
    'bin': 'application/octet-stream',                                                                                 // 10
    'bz': 'application/x-bzip',                                                                                        // 11
    'bz2': 'application/x-bzip2',                                                                                      // 12
    'eps': 'application/postscript',                                                                                   // 13
    'exe': 'application/octet-stream',                                                                                 // 14
    'gz': 'application/x-gzip',                                                                                        // 15
    'gzip': 'application/x-gzip',                                                                                      // 16
    'js': 'application/javascript',                                                                                    // 17
    'json': 'application/json',                                                                                        // 18
    'ogg': 'application/ogg',                                                                                          // 19
    'pdf': 'application/pdf',                                                                                          // 20
    'ps': 'application/postscript',                                                                                    // 21
    'psd': 'application/octet-stream',                                                                                 // 22
    'rar': 'application/x-rar-compressed',                                                                             // 23
    'rev': 'application/x-rar-compressed',                                                                             // 24
    'swf': 'application/x-shockwave-flash',                                                                            // 25
    'tar': 'application/x-tar',                                                                                        // 26
    'xhtml': 'application/xhtml+xml',                                                                                  // 27
    'xml': 'application/xml',                                                                                          // 28
    'zip': 'application/zip',                                                                                          // 29
                                                                                                                       //
    // audio                                                                                                           //
    'aif': 'audio/aiff',                                                                                               // 32
    'aifc': 'audio/aiff',                                                                                              // 33
    'aiff': 'audio/aiff',                                                                                              // 34
    'au': 'audio/basic',                                                                                               // 35
    'midi': 'audio/midi',                                                                                              // 36
    'mp2': 'audio/mpeg',                                                                                               // 37
    'mp3': 'audio/mpeg',                                                                                               // 38
    'mpa': 'audio/mpeg',                                                                                               // 39
    'ra': 'audio/vnd.rn-realaudio',                                                                                    // 40
    'wav': 'audio/x-wav',                                                                                              // 41
    'weba': 'audio/webm',                                                                                              // 42
    'wma': 'audio/x-ms-wma',                                                                                           // 43
                                                                                                                       //
    // image                                                                                                           //
    'avs': 'image/avs-video',                                                                                          // 46
    'bmp': 'image/x-windows-bmp',                                                                                      // 47
    'gif': 'image/gif',                                                                                                // 48
    'ico': 'image/vnd.microsoft.icon',                                                                                 // 49
    'jpeg': 'image/jpeg',                                                                                              // 50
    'jpg': 'image/jpg',                                                                                                // 51
    'mjpg': 'image/x-motion-jpeg',                                                                                     // 52
    'pic': 'image/pic',                                                                                                // 53
    'png': 'image/png',                                                                                                // 54
    'svg': 'image/svg+xml',                                                                                            // 55
    'tif': 'image/tiff',                                                                                               // 56
    'tiff': 'image/tiff',                                                                                              // 57
                                                                                                                       //
    // text                                                                                                            //
    'css': 'text/css',                                                                                                 // 60
    'csv': 'text/csv',                                                                                                 // 61
    'html': 'text/html',                                                                                               // 62
    'txt': 'text/plain',                                                                                               // 63
                                                                                                                       //
    // video                                                                                                           //
    'avi': 'video/avi',                                                                                                // 66
    'dv': 'video/x-dv',                                                                                                // 67
    'flv': 'video/x-flv',                                                                                              // 68
    'mov': 'video/quicktime',                                                                                          // 69
    'mp4': 'video/mp4',                                                                                                // 70
    'mpeg': 'video/mpeg',                                                                                              // 71
    'mpg': 'video/mpg',                                                                                                // 72
    'vdo': 'video/vdo',                                                                                                // 73
    'webm': 'video/webm',                                                                                              // 74
    'wmv': 'video/x-ms-wmv',                                                                                           // 75
                                                                                                                       //
    // specific to vendors                                                                                             //
    'doc': 'application/msword',                                                                                       // 78
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',                                 // 79
    'odb': 'application/vnd.oasis.opendocument.database',                                                              // 80
    'odc': 'application/vnd.oasis.opendocument.chart',                                                                 // 81
    'odf': 'application/vnd.oasis.opendocument.formula',                                                               // 82
    'odg': 'application/vnd.oasis.opendocument.graphics',                                                              // 83
    'odi': 'application/vnd.oasis.opendocument.image',                                                                 // 84
    'odm': 'application/vnd.oasis.opendocument.text-master',                                                           // 85
    'odp': 'application/vnd.oasis.opendocument.presentation',                                                          // 86
    'ods': 'application/vnd.oasis.opendocument.spreadsheet',                                                           // 87
    'odt': 'application/vnd.oasis.opendocument.text',                                                                  // 88
    'otg': 'application/vnd.oasis.opendocument.graphics-template',                                                     // 89
    'otp': 'application/vnd.oasis.opendocument.presentation-template',                                                 // 90
    'ots': 'application/vnd.oasis.opendocument.spreadsheet-template',                                                  // 91
    'ott': 'application/vnd.oasis.opendocument.text-template',                                                         // 92
    'ppt': 'application/vnd.ms-powerpoint',                                                                            // 93
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',                               // 94
    'xls': 'application/vnd.ms-excel',                                                                                 // 95
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'                                        // 96
                                                                                                                       //
};                                                                                                                     // 4
                                                                                                                       //
/**                                                                                                                    //
 * Adds the MIME type for an extension                                                                                 //
 * @param extension                                                                                                    //
 * @param mime                                                                                                         //
 */                                                                                                                    //
UploadFS.addMimeType = function (extension, mime) {                                                                    // 105
    MIME[extension.toLowerCase()] = mime;                                                                              // 106
};                                                                                                                     // 107
                                                                                                                       //
/**                                                                                                                    //
 * Returns the MIME type of the extension                                                                              //
 * @param extension                                                                                                    //
 * @returns {*}                                                                                                        //
 */                                                                                                                    //
UploadFS.getMimeType = function (extension) {                                                                          // 114
    if (extension) {                                                                                                   // 115
        extension = extension.toLowerCase();                                                                           // 116
        return MIME[extension];                                                                                        // 117
    }                                                                                                                  // 118
};                                                                                                                     // 119
                                                                                                                       //
/**                                                                                                                    //
 * Returns all MIME types                                                                                              //
 */                                                                                                                    //
UploadFS.getMimeTypes = function () {                                                                                  // 124
    return MIME;                                                                                                       // 125
};                                                                                                                     // 126
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ufs-utilities.js":["meteor/meteor","meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-utilities.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});
                                                                                                                       // 2
                                                                                                                       //
if (Meteor.isClient) {                                                                                                 // 5
                                                                                                                       //
    /**                                                                                                                //
     * Returns file and data as ArrayBuffer for each files in the event                                                //
     * @deprecated                                                                                                     //
     * @param event                                                                                                    //
     * @param callback                                                                                                 //
     */                                                                                                                //
    // todo remove deprecated method                                                                                   //
    UploadFS.readAsArrayBuffer = function (event, callback) {                                                          // 14
        console.error('UploadFS.readAsArrayBuffer is deprecated, see https://github.com/jalik/jalik-ufs#uploading-from-a-file');
    };                                                                                                                 // 16
                                                                                                                       //
    /**                                                                                                                //
     * Opens a dialog to select a single file                                                                          //
     * @param callback                                                                                                 //
     */                                                                                                                //
    UploadFS.selectFile = function (callback) {                                                                        // 22
        var input = document.createElement('input');                                                                   // 23
        input.type = 'file';                                                                                           // 24
        input.multiple = false;                                                                                        // 25
        input.onchange = function (ev) {                                                                               // 26
            var files = ev.target.files;                                                                               // 27
            callback.call(UploadFS, files[0]);                                                                         // 28
        };                                                                                                             // 29
        // Fix for iOS                                                                                                 //
        input.style = 'display:none';                                                                                  // 31
        document.body.appendChild(input);                                                                              // 32
        input.click();                                                                                                 // 33
    };                                                                                                                 // 34
                                                                                                                       //
    /**                                                                                                                //
     * Opens a dialog to select multiple files                                                                         //
     * @param callback                                                                                                 //
     */                                                                                                                //
    UploadFS.selectFiles = function (callback) {                                                                       // 40
        var input = document.createElement('input');                                                                   // 41
        input.type = 'file';                                                                                           // 42
        input.multiple = true;                                                                                         // 43
        input.onchange = function (ev) {                                                                               // 44
            var files = ev.target.files;                                                                               // 45
                                                                                                                       //
            for (var i = 0; i < files.length; i += 1) {                                                                // 47
                callback.call(UploadFS, files[i]);                                                                     // 48
            }                                                                                                          // 49
        };                                                                                                             // 50
        // Fix for iOS                                                                                                 //
        input.style = 'display:none';                                                                                  // 52
        document.body.appendChild(input);                                                                              // 53
        input.click();                                                                                                 // 54
    };                                                                                                                 // 55
}                                                                                                                      // 56
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 59
                                                                                                                       //
    /**                                                                                                                //
     * Adds the path attribute to files                                                                                //
     * @param where                                                                                                    //
     */                                                                                                                //
    UploadFS.addPathAttributeToFiles = function (where) {                                                              // 65
        _.each(UploadFS.getStores(), function (store) {                                                                // 66
            var files = store.getCollection();                                                                         // 67
                                                                                                                       //
            // By default update only files with no path set                                                           //
            files.find(where || { path: null }, { fields: { _id: 1 } }).forEach(function (file) {                      // 70
                var path = store.getFileRelativeURL(file._id);                                                         // 71
                files.update({ _id: file._id }, { $set: { path: path } });                                             // 72
            });                                                                                                        // 73
        });                                                                                                            // 74
    };                                                                                                                 // 75
}                                                                                                                      // 76
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-config.js":["meteor/underscore","meteor/meteor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-config.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                       // 2
                                                                                                                       //
/**                                                                                                                    //
 * UploadFS configuration                                                                                              //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.Config = function (options) {                                                                                 // 9
    // Set default options                                                                                             //
    options = _.extend({                                                                                               // 11
        https: false,                                                                                                  // 12
        simulateReadDelay: 0,                                                                                          // 13
        simulateUploadSpeed: 0,                                                                                        // 14
        simulateWriteDelay: 0,                                                                                         // 15
        storesPath: 'ufs',                                                                                             // 16
        tmpDir: '/tmp/ufs',                                                                                            // 17
        tmpDirPermissions: '0700'                                                                                      // 18
    }, options);                                                                                                       // 11
                                                                                                                       //
    // Check options                                                                                                   //
    if (typeof options.https !== 'boolean') {                                                                          // 22
        throw new TypeError('https is not a function');                                                                // 23
    }                                                                                                                  // 24
    if (typeof options.simulateReadDelay !== 'number') {                                                               // 25
        throw new Meteor.Error('simulateReadDelay is not a number');                                                   // 26
    }                                                                                                                  // 27
    if (typeof options.simulateUploadSpeed !== 'number') {                                                             // 28
        throw new Meteor.Error('simulateUploadSpeed is not a number');                                                 // 29
    }                                                                                                                  // 30
    if (typeof options.simulateWriteDelay !== 'number') {                                                              // 31
        throw new Meteor.Error('simulateWriteDelay is not a number');                                                  // 32
    }                                                                                                                  // 33
    if (typeof options.storesPath !== 'string') {                                                                      // 34
        throw new Meteor.Error('storesPath is not a string');                                                          // 35
    }                                                                                                                  // 36
    if (typeof options.tmpDir !== 'string') {                                                                          // 37
        throw new Meteor.Error('tmpDir is not a string');                                                              // 38
    }                                                                                                                  // 39
    if (typeof options.tmpDirPermissions !== 'string') {                                                               // 40
        throw new Meteor.Error('tmpDirPermissions is not a string');                                                   // 41
    }                                                                                                                  // 42
                                                                                                                       //
    // Public attributes                                                                                               //
    this.https = options.https;                                                                                        // 45
    this.simulateReadDelay = parseInt(options.simulateReadDelay);                                                      // 46
    this.simulateUploadSpeed = parseInt(options.simulateUploadSpeed);                                                  // 47
    this.simulateWriteDelay = parseInt(options.simulateWriteDelay);                                                    // 48
    this.storesPath = options.storesPath;                                                                              // 49
    this.tmpDir = options.tmpDir;                                                                                      // 50
    this.tmpDirPermissions = options.tmpDirPermissions;                                                                // 51
};                                                                                                                     // 52
                                                                                                                       //
/**                                                                                                                    //
 * Simulation read delay in milliseconds                                                                               //
 * @type {number}                                                                                                      //
 */                                                                                                                    //
UploadFS.Config.prototype.simulateReadDelay = 0;                                                                       // 58
                                                                                                                       //
/**                                                                                                                    //
 * Simulation upload speed in milliseconds                                                                             //
 * @type {number}                                                                                                      //
 */                                                                                                                    //
UploadFS.Config.prototype.simulateUploadSpeed = 0;                                                                     // 64
                                                                                                                       //
/**                                                                                                                    //
 * Simulation write delay in milliseconds                                                                              //
 * @type {number}                                                                                                      //
 */                                                                                                                    //
UploadFS.Config.prototype.simulateWriteDelay = 0;                                                                      // 70
                                                                                                                       //
/**                                                                                                                    //
 * URL path to stores                                                                                                  //
 * @type {string}                                                                                                      //
 */                                                                                                                    //
UploadFS.Config.prototype.storesPath = null;                                                                           // 76
                                                                                                                       //
/**                                                                                                                    //
 * Local temporary directory for uploading files                                                                       //
 * @type {string}                                                                                                      //
 */                                                                                                                    //
UploadFS.Config.prototype.tmpDir = null;                                                                               // 82
                                                                                                                       //
/**                                                                                                                    //
 * Permissions of the local temporary directory                                                                        //
 * @type {string}                                                                                                      //
 */                                                                                                                    //
UploadFS.Config.prototype.tmpDirPermissions = '0700';                                                                  // 88
                                                                                                                       //
/**                                                                                                                    //
 * Global configuration                                                                                                //
 * @type {UploadFS.Config}                                                                                             //
 */                                                                                                                    //
UploadFS.config = new UploadFS.Config();                                                                               // 94
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-filter.js":["babel-runtime/helpers/typeof","meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-filter.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});
                                                                                                                       // 1
                                                                                                                       //
/**                                                                                                                    //
 * File filter                                                                                                         //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.Filter = function (options) {                                                                                 // 8
    var self = this;                                                                                                   // 9
                                                                                                                       //
    // Set default options                                                                                             //
    options = _.extend({                                                                                               // 12
        contentTypes: null,                                                                                            // 13
        extensions: null,                                                                                              // 14
        minSize: 1,                                                                                                    // 15
        maxSize: 0,                                                                                                    // 16
        onCheck: null                                                                                                  // 17
    }, options);                                                                                                       // 12
                                                                                                                       //
    // Check options                                                                                                   //
    if (options.contentTypes && !(options.contentTypes instanceof Array)) {                                            // 21
        throw new TypeError('contentTypes is not an Array');                                                           // 22
    }                                                                                                                  // 23
    if (options.extensions && !(options.extensions instanceof Array)) {                                                // 24
        throw new TypeError('extensions is not an Array');                                                             // 25
    }                                                                                                                  // 26
    if (typeof options.minSize !== 'number') {                                                                         // 27
        throw new TypeError('minSize is not a number');                                                                // 28
    }                                                                                                                  // 29
    if (typeof options.maxSize !== 'number') {                                                                         // 30
        throw new TypeError('maxSize is not a number');                                                                // 31
    }                                                                                                                  // 32
    if (options.onCheck && typeof options.onCheck !== 'function') {                                                    // 33
        throw new TypeError('onCheck is not a function');                                                              // 34
    }                                                                                                                  // 35
                                                                                                                       //
    // Private attributes                                                                                              //
    var contentTypes = options.contentTypes;                                                                           // 38
    var extensions = options.extensions;                                                                               // 39
    var onCheck = options.onCheck;                                                                                     // 40
    var maxSize = parseInt(options.maxSize);                                                                           // 41
    var minSize = parseInt(options.minSize);                                                                           // 42
                                                                                                                       //
    /**                                                                                                                //
     * Checks the file                                                                                                 //
     * @param file                                                                                                     //
     */                                                                                                                //
    self.check = function (file) {                                                                                     // 48
        // Check size                                                                                                  //
        if (file.size <= 0 || file.size < self.getMinSize()) {                                                         // 50
            throw new Meteor.Error('file-too-small', 'File is too small (min =' + self.getMinSize() + ')');            // 51
        }                                                                                                              // 52
        if (self.getMaxSize() > 0 && file.size > self.getMaxSize()) {                                                  // 53
            throw new Meteor.Error('file-too-large', 'File is too large (max = ' + self.getMaxSize() + ')');           // 54
        }                                                                                                              // 55
        // Check extension                                                                                             //
        if (self.getExtensions() && !_.contains(self.getExtensions(), file.extension)) {                               // 57
            throw new Meteor.Error('invalid-file-extension', 'File extension is not accepted');                        // 58
        }                                                                                                              // 59
        // Check content type                                                                                          //
        if (self.getContentTypes() && !checkContentType(file.type, self.getContentTypes())) {                          // 61
            throw new Meteor.Error('invalid-file-type', 'File type is not accepted');                                  // 62
        }                                                                                                              // 63
        // Apply custom check                                                                                          //
        if (typeof onCheck === 'function' && !onCheck.call(self, file)) {                                              // 65
            throw new Meteor.Error('invalid-file', 'File does not match filter');                                      // 66
        }                                                                                                              // 67
    };                                                                                                                 // 68
                                                                                                                       //
    /**                                                                                                                //
     * Returns the allowed content types                                                                               //
     * @return {Array}                                                                                                 //
     */                                                                                                                //
    self.getContentTypes = function () {                                                                               // 74
        return contentTypes;                                                                                           // 75
    };                                                                                                                 // 76
                                                                                                                       //
    /**                                                                                                                //
     * Returns the allowed extensions                                                                                  //
     * @return {Array}                                                                                                 //
     */                                                                                                                //
    self.getExtensions = function () {                                                                                 // 82
        return extensions;                                                                                             // 83
    };                                                                                                                 // 84
                                                                                                                       //
    /**                                                                                                                //
     * Returns the maximum file size                                                                                   //
     * @return {Number}                                                                                                //
     */                                                                                                                //
    self.getMaxSize = function () {                                                                                    // 90
        return maxSize;                                                                                                // 91
    };                                                                                                                 // 92
                                                                                                                       //
    /**                                                                                                                //
     * Returns the minimum file size                                                                                   //
     * @return {Number}                                                                                                //
     */                                                                                                                //
    self.getMinSize = function () {                                                                                    // 98
        return minSize;                                                                                                // 99
    };                                                                                                                 // 100
                                                                                                                       //
    /**                                                                                                                //
     * Checks if the file matches filter                                                                               //
     * @param file                                                                                                     //
     * @return {boolean}                                                                                               //
     */                                                                                                                //
    self.isValid = function (file) {                                                                                   // 107
        var result = true;                                                                                             // 108
        try {                                                                                                          // 109
            self.check(file);                                                                                          // 110
        } catch (err) {                                                                                                // 111
            result = false;                                                                                            // 112
        }                                                                                                              // 113
        return result;                                                                                                 // 114
    };                                                                                                                 // 115
};                                                                                                                     // 116
                                                                                                                       //
function checkContentType(type, list) {                                                                                // 118
    if (type) {                                                                                                        // 119
        if (_.contains(list, type)) {                                                                                  // 120
            return true;                                                                                               // 121
        } else {                                                                                                       // 122
            var _ret = function () {                                                                                   // 122
                var wildCardGlob = '/*';                                                                               // 123
                var wildcards = _.filter(list, function (item) {                                                       // 124
                    return item.indexOf(wildCardGlob) > 0;                                                             // 125
                });                                                                                                    // 126
                                                                                                                       //
                if (_.contains(wildcards, type.replace(/(\/.*)$/, wildCardGlob))) {                                    // 128
                    return {                                                                                           // 129
                        v: true                                                                                        // 129
                    };                                                                                                 // 129
                }                                                                                                      // 130
            }();                                                                                                       // 122
                                                                                                                       //
            if ((typeof _ret === 'undefined' ? 'undefined' : _typeof(_ret)) === "object") return _ret.v;               // 122
        }                                                                                                              // 131
    }                                                                                                                  // 132
    return false;                                                                                                      // 133
}                                                                                                                      // 134
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-store-permissions.js":["meteor/underscore",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-store-permissions.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});                                                       // 1
                                                                                                                       //
/**                                                                                                                    //
 * Store permissions                                                                                                   //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.StorePermissions = function (options) {                                                                       // 8
    var self = this;                                                                                                   // 9
                                                                                                                       //
    options = _.extend({                                                                                               // 11
        insert: null,                                                                                                  // 12
        remove: null,                                                                                                  // 13
        update: null                                                                                                   // 14
    }, options);                                                                                                       // 11
                                                                                                                       //
    if (typeof options.insert === 'function') {                                                                        // 17
        self.insert = options.insert;                                                                                  // 18
    }                                                                                                                  // 19
    if (typeof options.remove === 'function') {                                                                        // 20
        self.remove = options.remove;                                                                                  // 21
    }                                                                                                                  // 22
    if (typeof options.update === 'function') {                                                                        // 23
        self.update = options.update;                                                                                  // 24
    }                                                                                                                  // 25
                                                                                                                       //
    self.checkInsert = function (userId, file) {                                                                       // 27
        if (typeof self.insert === 'function') {                                                                       // 28
            self.insert.call(self, userId, file);                                                                      // 29
        }                                                                                                              // 30
    };                                                                                                                 // 31
    self.checkRemove = function (userId, file) {                                                                       // 32
        if (typeof self.remove === 'function') {                                                                       // 33
            self.remove.call(self, userId, file);                                                                      // 34
        }                                                                                                              // 35
    };                                                                                                                 // 36
    self.checkUpdate = function (userId, file) {                                                                       // 37
        if (typeof self.update === 'function') {                                                                       // 38
            self.update.call(self, userId, file);                                                                      // 39
        }                                                                                                              // 40
    };                                                                                                                 // 41
};                                                                                                                     // 42
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-store.js":["meteor/underscore","meteor/meteor","meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-store.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
/**                                                                                                                    //
 * File store                                                                                                          //
 * @param options                                                                                                      //
 * @constructor                                                                                                        //
 */                                                                                                                    //
UploadFS.Store = function (options) {                                                                                  // 10
    var self = this;                                                                                                   // 11
                                                                                                                       //
    // Set default options                                                                                             //
    options = _.extend({                                                                                               // 14
        collection: null,                                                                                              // 15
        filter: null,                                                                                                  // 16
        name: null,                                                                                                    // 17
        onCopyError: null,                                                                                             // 18
        onFinishUpload: null,                                                                                          // 19
        onRead: null,                                                                                                  // 20
        onReadError: null,                                                                                             // 21
        onWriteError: null,                                                                                            // 22
        permissions: null,                                                                                             // 23
        transformRead: null,                                                                                           // 24
        transformWrite: null                                                                                           // 25
    }, options);                                                                                                       // 14
                                                                                                                       //
    // Check instance                                                                                                  //
    if (!(self instanceof UploadFS.Store)) {                                                                           // 29
        throw new Error('UploadFS.Store is not an instance');                                                          // 30
    }                                                                                                                  // 31
                                                                                                                       //
    // Check options                                                                                                   //
    if (!(options.collection instanceof Mongo.Collection)) {                                                           // 34
        throw new TypeError('collection is not a Mongo.Collection');                                                   // 35
    }                                                                                                                  // 36
    if (options.filter && !(options.filter instanceof UploadFS.Filter)) {                                              // 37
        throw new TypeError('filter is not a UploadFS.Filter');                                                        // 38
    }                                                                                                                  // 39
    if (typeof options.name !== 'string') {                                                                            // 40
        throw new TypeError('name is not a string');                                                                   // 41
    }                                                                                                                  // 42
    if (UploadFS.getStore(options.name)) {                                                                             // 43
        throw new TypeError('name already exists');                                                                    // 44
    }                                                                                                                  // 45
    if (options.onCopyError && typeof options.onCopyError !== 'function') {                                            // 46
        throw new TypeError('onCopyError is not a function');                                                          // 47
    }                                                                                                                  // 48
    if (options.onFinishUpload && typeof options.onFinishUpload !== 'function') {                                      // 49
        throw new TypeError('onFinishUpload is not a function');                                                       // 50
    }                                                                                                                  // 51
    if (options.onRead && typeof options.onRead !== 'function') {                                                      // 52
        throw new TypeError('onRead is not a function');                                                               // 53
    }                                                                                                                  // 54
    if (options.onReadError && typeof options.onReadError !== 'function') {                                            // 55
        throw new TypeError('onReadError is not a function');                                                          // 56
    }                                                                                                                  // 57
    if (options.onWriteError && typeof options.onWriteError !== 'function') {                                          // 58
        throw new TypeError('onWriteError is not a function');                                                         // 59
    }                                                                                                                  // 60
    if (options.permissions && !(options.permissions instanceof UploadFS.StorePermissions)) {                          // 61
        throw new TypeError('permissions is not a UploadFS.StorePermissions');                                         // 62
    }                                                                                                                  // 63
    if (options.transformRead && typeof options.transformRead !== 'function') {                                        // 64
        throw new TypeError('transformRead is not a function');                                                        // 65
    }                                                                                                                  // 66
    if (options.transformWrite && typeof options.transformWrite !== 'function') {                                      // 67
        throw new TypeError('transformWrite is not a function');                                                       // 68
    }                                                                                                                  // 69
                                                                                                                       //
    // Public attributes                                                                                               //
    self.onCopyError = options.onCopyError || self.onCopyError;                                                        // 72
    self.onFinishUpload = options.onFinishUpload || self.onFinishUpload;                                               // 73
    self.onRead = options.onRead || self.onRead;                                                                       // 74
    self.onReadError = options.onReadError || self.onReadError;                                                        // 75
    self.onWriteError = options.onWriteError || self.onWriteError;                                                     // 76
    self.permissions = options.permissions || new UploadFS.StorePermissions();                                         // 77
                                                                                                                       //
    // Private attributes                                                                                              //
    var collection = options.collection;                                                                               // 80
    var copyTo = options.copyTo;                                                                                       // 81
    var filter = options.filter;                                                                                       // 82
    var name = options.name;                                                                                           // 83
    var transformRead = options.transformRead;                                                                         // 84
    var transformWrite = options.transformWrite;                                                                       // 85
                                                                                                                       //
    // Add the store to the list                                                                                       //
    UploadFS.getStores()[name] = self;                                                                                 // 88
                                                                                                                       //
    /**                                                                                                                //
     * Returns the collection                                                                                          //
     * @return {Mongo.Collection}                                                                                      //
     */                                                                                                                //
    self.getCollection = function () {                                                                                 // 94
        return collection;                                                                                             // 95
    };                                                                                                                 // 96
                                                                                                                       //
    /**                                                                                                                //
     * Returns the file filter                                                                                         //
     * @return {UploadFS.Filter}                                                                                       //
     */                                                                                                                //
    self.getFilter = function () {                                                                                     // 102
        return filter;                                                                                                 // 103
    };                                                                                                                 // 104
                                                                                                                       //
    /**                                                                                                                //
     * Returns the store name                                                                                          //
     * @return {string}                                                                                                //
     */                                                                                                                //
    self.getName = function () {                                                                                       // 110
        return name;                                                                                                   // 111
    };                                                                                                                 // 112
                                                                                                                       //
    /**                                                                                                                //
     * Defines the store permissions                                                                                   //
     * @param permissions                                                                                              //
     */                                                                                                                //
    self.setPermissions = function (permissions) {                                                                     // 118
        if (!(permissions instanceof UploadFS.StorePermissions)) {                                                     // 119
            throw new TypeError("permissions is not an instance of UploadFS.StorePermissions");                        // 120
        }                                                                                                              // 121
        self.permissions = permissions;                                                                                // 122
    };                                                                                                                 // 123
                                                                                                                       //
    if (Meteor.isServer) {                                                                                             // 125
                                                                                                                       //
        /**                                                                                                            //
         * Checks token validity                                                                                       //
         * @param token                                                                                                //
         * @param fileId                                                                                               //
         * @returns {boolean}                                                                                          //
         */                                                                                                            //
        self.checkToken = function (token, fileId) {                                                                   // 133
            check(token, String);                                                                                      // 134
            check(fileId, String);                                                                                     // 135
            return UploadFS.tokens.find({ value: token, fileId: fileId }).count() === 1;                               // 136
        };                                                                                                             // 137
                                                                                                                       //
        /**                                                                                                            //
         * Copies the file to a store                                                                                  //
         * @param fileId                                                                                               //
         * @param store                                                                                                //
         * @param callback                                                                                             //
         */                                                                                                            //
        self.copy = function (fileId, store, callback) {                                                               // 145
            check(fileId, String);                                                                                     // 146
                                                                                                                       //
            if (!(store instanceof UploadFS.Store)) {                                                                  // 148
                throw new TypeError('store is not a UploadFS.store.Store');                                            // 149
            }                                                                                                          // 150
            // Get original file                                                                                       //
            var file = collection.findOne({ _id: fileId });                                                            // 152
            if (!file) {                                                                                               // 153
                throw new Meteor.Error(404, 'File not found');                                                         // 154
            }                                                                                                          // 155
            // Ignore the file if it does not match store filter                                                       //
            var filter = store.getFilter();                                                                            // 157
            if (filter instanceof UploadFS.Filter && !filter.isValid(file)) {                                          // 158
                return;                                                                                                // 159
            }                                                                                                          // 160
                                                                                                                       //
            // Prepare copy                                                                                            //
            var copy = _.omit(file, '_id', 'url');                                                                     // 163
            copy.originalStore = self.getName();                                                                       // 164
            copy.originalId = fileId;                                                                                  // 165
                                                                                                                       //
            // Create the copy                                                                                         //
            var copyId = store.create(copy);                                                                           // 168
                                                                                                                       //
            // Get original stream                                                                                     //
            var rs = self.getReadStream(fileId, file);                                                                 // 171
                                                                                                                       //
            // Catch errors to avoid app crashing                                                                      //
            rs.on('error', Meteor.bindEnvironment(function (err) {                                                     // 174
                callback.call(self, err, null);                                                                        // 175
            }));                                                                                                       // 176
                                                                                                                       //
            // Copy file data                                                                                          //
            store.write(rs, copyId, Meteor.bindEnvironment(function (err) {                                            // 179
                if (err) {                                                                                             // 180
                    collection.remove({ _id: copyId });                                                                // 181
                    self.onCopyError.call(self, err, fileId, file);                                                    // 182
                }                                                                                                      // 183
                if (typeof callback === 'function') {                                                                  // 184
                    callback.call(self, err, copyId, copy, store);                                                     // 185
                }                                                                                                      // 186
            }));                                                                                                       // 187
        };                                                                                                             // 188
                                                                                                                       //
        /**                                                                                                            //
         * Creates the file in the collection                                                                          //
         * @param file                                                                                                 //
         * @param callback                                                                                             //
         * @return {string}                                                                                            //
         */                                                                                                            //
        self.create = function (file, callback) {                                                                      // 196
            check(file, Object);                                                                                       // 197
            file.store = name;                                                                                         // 198
            return collection.insert(file, callback);                                                                  // 199
        };                                                                                                             // 200
                                                                                                                       //
        /**                                                                                                            //
         * Creates a token for the file (only needed for client side upload)                                           //
         * @param fileId                                                                                               //
         * @returns {*}                                                                                                //
         */                                                                                                            //
        self.createToken = function (fileId) {                                                                         // 207
            var token = self.generateToken();                                                                          // 208
                                                                                                                       //
            // Check if token exists                                                                                   //
            if (UploadFS.tokens.find({ fileId: fileId }).count()) {                                                    // 211
                UploadFS.tokens.update({ fileId: fileId }, {                                                           // 212
                    $set: {                                                                                            // 213
                        createdAt: new Date(),                                                                         // 214
                        value: token                                                                                   // 215
                    }                                                                                                  // 213
                });                                                                                                    // 212
            } else {                                                                                                   // 218
                UploadFS.tokens.insert({                                                                               // 219
                    createdAt: new Date(),                                                                             // 220
                    fileId: fileId,                                                                                    // 221
                    value: token                                                                                       // 222
                });                                                                                                    // 219
            }                                                                                                          // 224
            return token;                                                                                              // 225
        };                                                                                                             // 226
                                                                                                                       //
        /**                                                                                                            //
         * Generates a random token                                                                                    //
         * @param pattern                                                                                              //
         * @return {string}                                                                                            //
         */                                                                                                            //
        self.generateToken = function (pattern) {                                                                      // 233
            return (pattern || 'xyxyxyxyxy').replace(/[xy]/g, function (c) {                                           // 234
                var r = Math.random() * 16 | 0,                                                                        // 235
                    v = c == 'x' ? r : r & 0x3 | 0x8;                                                                  // 235
                var s = v.toString(16);                                                                                // 236
                return Math.round(Math.random()) ? s.toUpperCase() : s;                                                // 237
            });                                                                                                        // 238
        };                                                                                                             // 239
                                                                                                                       //
        /**                                                                                                            //
         * Transforms the file on reading                                                                              //
         * @param readStream                                                                                           //
         * @param writeStream                                                                                          //
         * @param fileId                                                                                               //
         * @param file                                                                                                 //
         * @param request                                                                                              //
         * @param headers                                                                                              //
         */                                                                                                            //
        self.transformRead = function (readStream, writeStream, fileId, file, request, headers) {                      // 250
            if (typeof transformRead === 'function') {                                                                 // 251
                transformRead.call(self, readStream, writeStream, fileId, file, request, headers);                     // 252
            } else {                                                                                                   // 253
                readStream.pipe(writeStream);                                                                          // 254
            }                                                                                                          // 255
        };                                                                                                             // 256
                                                                                                                       //
        /**                                                                                                            //
         * Transforms the file on writing                                                                              //
         * @param readStream                                                                                           //
         * @param writeStream                                                                                          //
         * @param fileId                                                                                               //
         * @param file                                                                                                 //
         */                                                                                                            //
        self.transformWrite = function (readStream, writeStream, fileId, file) {                                       // 265
            if (typeof transformWrite === 'function') {                                                                // 266
                transformWrite.call(self, readStream, writeStream, fileId, file);                                      // 267
            } else {                                                                                                   // 268
                readStream.pipe(writeStream);                                                                          // 269
            }                                                                                                          // 270
        };                                                                                                             // 271
                                                                                                                       //
        /**                                                                                                            //
         * Writes the file to the store                                                                                //
         * @param rs                                                                                                   //
         * @param fileId                                                                                               //
         * @param callback                                                                                             //
         */                                                                                                            //
        self.write = function (rs, fileId, callback) {                                                                 // 279
            var file = collection.findOne({ _id: fileId });                                                            // 280
            var ws = self.getWriteStream(fileId, file);                                                                // 281
                                                                                                                       //
            var errorHandler = Meteor.bindEnvironment(function (err) {                                                 // 283
                collection.remove({ _id: fileId });                                                                    // 284
                self.onWriteError.call(self, err, fileId, file);                                                       // 285
                callback.call(self, err);                                                                              // 286
            });                                                                                                        // 287
                                                                                                                       //
            ws.on('error', errorHandler);                                                                              // 289
            ws.on('finish', Meteor.bindEnvironment(function () {                                                       // 290
                var size = 0;                                                                                          // 291
                var readStream = self.getReadStream(fileId, file);                                                     // 292
                                                                                                                       //
                readStream.on('error', Meteor.bindEnvironment(function (error) {                                       // 294
                    callback.call(self, error, null);                                                                  // 295
                }));                                                                                                   // 296
                readStream.on('data', Meteor.bindEnvironment(function (data) {                                         // 297
                    size += data.length;                                                                               // 298
                }));                                                                                                   // 299
                readStream.on('end', Meteor.bindEnvironment(function () {                                              // 300
                    // Set file attribute                                                                              //
                    file.complete = true;                                                                              // 302
                    file.path = self.getFileRelativeURL(fileId);                                                       // 303
                    file.progress = 1;                                                                                 // 304
                    file.size = size;                                                                                  // 305
                    file.token = self.generateToken();                                                                 // 306
                    file.uploading = false;                                                                            // 307
                    file.uploadedAt = new Date();                                                                      // 308
                    file.url = self.getFileURL(fileId);                                                                // 309
                                                                                                                       //
                    // Sets the file URL when file transfer is complete,                                               //
                    // this way, the image will loads entirely.                                                        //
                    collection.update({ _id: fileId }, {                                                               // 313
                        $set: {                                                                                        // 314
                            complete: file.complete,                                                                   // 315
                            path: file.path,                                                                           // 316
                            progress: file.progress,                                                                   // 317
                            size: file.size,                                                                           // 318
                            token: file.token,                                                                         // 319
                            uploading: file.uploading,                                                                 // 320
                            uploadedAt: file.uploadedAt,                                                               // 321
                            url: file.url                                                                              // 322
                        }                                                                                              // 314
                    });                                                                                                // 313
                                                                                                                       //
                    // Return file info                                                                                //
                    callback.call(self, null, file);                                                                   // 327
                                                                                                                       //
                    // Execute callback                                                                                //
                    if (typeof self.onFinishUpload == 'function') {                                                    // 330
                        self.onFinishUpload.call(self, file);                                                          // 331
                    }                                                                                                  // 332
                                                                                                                       //
                    // Simulate write speed                                                                            //
                    if (UploadFS.config.simulateWriteDelay) {                                                          // 335
                        Meteor._sleepForMs(UploadFS.config.simulateWriteDelay);                                        // 336
                    }                                                                                                  // 337
                                                                                                                       //
                    // Copy file to other stores                                                                       //
                    if (copyTo instanceof Array) {                                                                     // 340
                        for (var i = 0; i < copyTo.length; i += 1) {                                                   // 341
                            var store = copyTo[i];                                                                     // 342
                                                                                                                       //
                            if (!store.getFilter() || store.getFilter().isValid(file)) {                               // 344
                                self.copy(fileId, store);                                                              // 345
                            }                                                                                          // 346
                        }                                                                                              // 347
                    }                                                                                                  // 348
                }));                                                                                                   // 349
            }));                                                                                                       // 350
                                                                                                                       //
            // Execute transformation                                                                                  //
            self.transformWrite(rs, ws, fileId, file);                                                                 // 353
        };                                                                                                             // 354
    }                                                                                                                  // 355
                                                                                                                       //
    if (Meteor.isServer) {                                                                                             // 357
        (function () {                                                                                                 // 357
            var fs = Npm.require('fs');                                                                                // 358
                                                                                                                       //
            // Code executed after removing file                                                                       //
            collection.after.remove(function (userId, file) {                                                          // 361
                // Remove associated tokens                                                                            //
                UploadFS.tokens.remove({ fileId: file._id });                                                          // 363
                                                                                                                       //
                if (copyTo instanceof Array) {                                                                         // 365
                    for (var i = 0; i < copyTo.length; i += 1) {                                                       // 366
                        // Remove copies in stores                                                                     //
                        copyTo[i].getCollection().remove({ originalId: file._id });                                    // 368
                    }                                                                                                  // 369
                }                                                                                                      // 370
            });                                                                                                        // 371
                                                                                                                       //
            // Code executed before inserting file                                                                     //
            collection.before.insert(function (userId, file) {                                                         // 374
                self.permissions.checkInsert(userId, file);                                                            // 375
            });                                                                                                        // 376
                                                                                                                       //
            // Code executed before updating file                                                                      //
            collection.before.update(function (userId, file, fields, modifiers) {                                      // 379
                self.permissions.checkUpdate(userId, file);                                                            // 380
            });                                                                                                        // 381
                                                                                                                       //
            // Code executed before removing file                                                                      //
            collection.before.remove(function (userId, file) {                                                         // 384
                self.permissions.checkRemove(userId, file);                                                            // 385
                                                                                                                       //
                // Delete the physical file in the store                                                               //
                self['delete'](file._id);                                                                              // 388
                                                                                                                       //
                var tmpFile = UploadFS.getTempFilePath(file._id);                                                      // 390
                                                                                                                       //
                // Delete the temp file                                                                                //
                fs.stat(tmpFile, function (err) {                                                                      // 393
                    !err && fs.unlink(tmpFile, function (err) {                                                        // 394
                        err && console.error('ufs: cannot delete temp file at ' + tmpFile + ' (' + err.message + ')');
                    });                                                                                                // 396
                });                                                                                                    // 397
            });                                                                                                        // 398
        })();                                                                                                          // 357
    }                                                                                                                  // 399
};                                                                                                                     // 400
                                                                                                                       //
/**                                                                                                                    //
 * Returns the file URL                                                                                                //
 * @param fileId                                                                                                       //
 */                                                                                                                    //
UploadFS.Store.prototype.getFileRelativeURL = function (fileId) {                                                      // 406
    var file = this.getCollection().findOne({ _id: fileId }, { fields: { name: 1 } });                                 // 407
    return file && this.getRelativeURL(fileId + '/' + encodeURIComponent(file.name));                                  // 408
};                                                                                                                     // 409
                                                                                                                       //
/**                                                                                                                    //
 * Returns the file URL                                                                                                //
 * @param fileId                                                                                                       //
 */                                                                                                                    //
UploadFS.Store.prototype.getFileURL = function (fileId) {                                                              // 415
    var file = this.getCollection().findOne({ _id: fileId }, { fields: { name: 1 } });                                 // 416
    return file && this.getURL(fileId + '/' + encodeURIComponent(file.name));                                          // 417
};                                                                                                                     // 418
                                                                                                                       //
/**                                                                                                                    //
 * Returns the store relative URL                                                                                      //
 * @param path                                                                                                         //
 */                                                                                                                    //
UploadFS.Store.prototype.getRelativeURL = function (path) {                                                            // 424
    return [UploadFS.config.storesPath, this.getName(), path].join('/').replace(/\/$/, '');                            // 425
};                                                                                                                     // 426
                                                                                                                       //
/**                                                                                                                    //
 * Returns the store absolute URL                                                                                      //
 * @param path                                                                                                         //
 */                                                                                                                    //
UploadFS.Store.prototype.getURL = function (path) {                                                                    // 432
    return Meteor.absoluteUrl(this.getRelativeURL(path), { secure: UploadFS.config.https });                           // 433
};                                                                                                                     // 434
                                                                                                                       //
/**                                                                                                                    //
 * Completes the file upload                                                                                           //
 * @param url                                                                                                          //
 * @param file                                                                                                         //
 * @param callback                                                                                                     //
 */                                                                                                                    //
UploadFS.Store.prototype.importFromURL = function (url, file, callback) {                                              // 442
    Meteor.call('ufsImportURL', url, file, this.getName(), callback);                                                  // 443
};                                                                                                                     // 444
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 446
    /**                                                                                                                //
     * Deletes a file async                                                                                            //
     * @param fileId                                                                                                   //
     * @param callback                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype['delete'] = function (fileId, callback) {                                                 // 452
        throw new Error('delete is not implemented');                                                                  // 453
    };                                                                                                                 // 454
                                                                                                                       //
    /**                                                                                                                //
     * Returns the file read stream                                                                                    //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     */                                                                                                                //
    UploadFS.Store.prototype.getReadStream = function (fileId, file) {                                                 // 461
        throw new Error('getReadStream is not implemented');                                                           // 462
    };                                                                                                                 // 463
                                                                                                                       //
    /**                                                                                                                //
     * Returns the file write stream                                                                                   //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     */                                                                                                                //
    UploadFS.Store.prototype.getWriteStream = function (fileId, file) {                                                // 470
        throw new Error('getWriteStream is not implemented');                                                          // 471
    };                                                                                                                 // 472
                                                                                                                       //
    /**                                                                                                                //
     * Callback for copy errors                                                                                        //
     * @param err                                                                                                      //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onCopyError = function (err, fileId, file) {                                              // 481
        console.error('ufs: cannot copy file "' + fileId + '" (' + err.message + ')', err);                            // 482
    };                                                                                                                 // 483
                                                                                                                       //
    /**                                                                                                                //
     * Called when a file has been uploaded                                                                            //
     * @param file                                                                                                     //
     */                                                                                                                //
    UploadFS.Store.prototype.onFinishUpload = function (file) {};                                                      // 489
                                                                                                                       //
    /**                                                                                                                //
     * Called when a file is read from the store                                                                       //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @param request                                                                                                  //
     * @param response                                                                                                 //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onRead = function (fileId, file, request, response) {                                     // 500
        return true;                                                                                                   // 501
    };                                                                                                                 // 502
                                                                                                                       //
    /**                                                                                                                //
     * Callback for read errors                                                                                        //
     * @param err                                                                                                      //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onReadError = function (err, fileId, file) {                                              // 511
        console.error('ufs: cannot read file "' + fileId + '" (' + err.message + ')', err);                            // 512
    };                                                                                                                 // 513
                                                                                                                       //
    /**                                                                                                                //
     * Callback for write errors                                                                                       //
     * @param err                                                                                                      //
     * @param fileId                                                                                                   //
     * @param file                                                                                                     //
     * @return boolean                                                                                                 //
     */                                                                                                                //
    UploadFS.Store.prototype.onWriteError = function (err, fileId, file) {                                             // 522
        console.error('ufs: cannot write file "' + fileId + '" (' + err.message + ')', err);                           // 523
    };                                                                                                                 // 524
}                                                                                                                      // 525
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-methods.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/check","meteor/meteor",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-methods.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var fs = Npm.require('fs');                                                                                            // 5
var http = Npm.require('http');                                                                                        // 6
var https = Npm.require('https');                                                                                      // 7
var Future = Npm.require('fibers/future');                                                                             // 8
                                                                                                                       //
Meteor.methods({                                                                                                       // 11
                                                                                                                       //
    /**                                                                                                                //
     * Completes the file transfer                                                                                     //
     * @param fileId                                                                                                   //
     * @param storeName                                                                                                //
     * @param token                                                                                                    //
     */                                                                                                                //
    ufsComplete: function ufsComplete(fileId, storeName, token) {                                                      // 19
        check(fileId, String);                                                                                         // 20
        check(storeName, String);                                                                                      // 21
        check(token, String);                                                                                          // 22
                                                                                                                       //
        // Get store                                                                                                   //
        var store = UploadFS.getStore(storeName);                                                                      // 25
        if (!store) {                                                                                                  // 26
            throw new Meteor.Error('invalid-store', "Store not found");                                                // 27
        }                                                                                                              // 28
        // Check token                                                                                                 //
        if (!store.checkToken(token, fileId)) {                                                                        // 30
            throw new Meteor.Error('invalid-token', "Token is not valid");                                             // 31
        }                                                                                                              // 32
                                                                                                                       //
        var fut = new Future();                                                                                        // 34
        var tmpFile = UploadFS.getTempFilePath(fileId);                                                                // 35
                                                                                                                       //
        // Get the temp file                                                                                           //
        var rs = fs.createReadStream(tmpFile, {                                                                        // 38
            flags: 'r',                                                                                                // 39
            encoding: null,                                                                                            // 40
            autoClose: true                                                                                            // 41
        });                                                                                                            // 38
                                                                                                                       //
        rs.on('error', Meteor.bindEnvironment(function (err) {                                                         // 44
            console.error(err);                                                                                        // 45
            store.getCollection().remove({ _id: fileId });                                                             // 46
            fut['throw'](err);                                                                                         // 47
        }));                                                                                                           // 48
                                                                                                                       //
        // Save file in the store                                                                                      //
        store.write(rs, fileId, Meteor.bindEnvironment(function (err, file) {                                          // 51
            fs.unlink(tmpFile, function (err) {                                                                        // 52
                err && console.error('ufs: cannot delete temp file "' + tmpFile + '" (' + err.message + ')');          // 53
            });                                                                                                        // 54
                                                                                                                       //
            if (err) {                                                                                                 // 56
                fut['throw'](err);                                                                                     // 57
            } else {                                                                                                   // 58
                // File has been fully uploaded                                                                        //
                // so we don't need to keep the token anymore.                                                         //
                // Also this ensure that the file cannot be modified with extra chunks later.                          //
                UploadFS.tokens.remove({ fileId: fileId });                                                            // 62
                fut['return'](file);                                                                                   // 63
            }                                                                                                          // 64
        }));                                                                                                           // 65
        return fut.wait();                                                                                             // 66
    },                                                                                                                 // 67
                                                                                                                       //
    /**                                                                                                                //
     * Creates the file and returns the file upload token                                                              //
     * @param file                                                                                                     //
     * @returns {{fileId: file, token: *, url}}                                                                        //
     */                                                                                                                //
    ufsCreate: function ufsCreate(file) {                                                                              // 74
        check(file, Object);                                                                                           // 75
                                                                                                                       //
        if (typeof file.name !== 'string' || !file.name.length) {                                                      // 77
            throw new Meteor.Error('invalid-file-name', "file name is not valid");                                     // 78
        }                                                                                                              // 79
        if (typeof file.store !== 'string' || !file.store.length) {                                                    // 80
            throw new Meteor.Error('invalid-store', "store is not valid");                                             // 81
        }                                                                                                              // 82
        // Get store                                                                                                   //
        var store = UploadFS.getStore(file.store);                                                                     // 84
        if (!store) {                                                                                                  // 85
            throw new Meteor.Error('invalid-store', "Store not found");                                                // 86
        }                                                                                                              // 87
                                                                                                                       //
        // Set default info                                                                                            //
        file.complete = false;                                                                                         // 90
        file.uploading = false;                                                                                        // 91
        file.extension = file.name && file.name.substr((~-file.name.lastIndexOf('.') >>> 0) + 2).toLowerCase();        // 92
        // Assign file MIME type based on the extension                                                                //
        if (file.extension && !file.type) {                                                                            // 94
            file.type = UploadFS.getMimeType(file.extension) || 'application/octet-stream';                            // 95
        }                                                                                                              // 96
        file.progress = 0;                                                                                             // 97
        file.size = parseInt(file.size) || 0;                                                                          // 98
        file.userId = file.userId || this.userId;                                                                      // 99
                                                                                                                       //
        // Check if the file matches store filter                                                                      //
        var filter = store.getFilter();                                                                                // 102
        if (filter instanceof UploadFS.Filter) {                                                                       // 103
            filter.check(file);                                                                                        // 104
        }                                                                                                              // 105
                                                                                                                       //
        // Create the file                                                                                             //
        var fileId = store.create(file);                                                                               // 108
        var token = store.createToken(fileId);                                                                         // 109
        var uploadUrl = store.getURL(fileId + '?token=' + token);                                                      // 110
                                                                                                                       //
        return {                                                                                                       // 112
            fileId: fileId,                                                                                            // 113
            token: token,                                                                                              // 114
            url: uploadUrl                                                                                             // 115
        };                                                                                                             // 112
    },                                                                                                                 // 117
                                                                                                                       //
    /**                                                                                                                //
     * Deletes a file                                                                                                  //
     * @param fileId                                                                                                   //
     * @param storeName                                                                                                //
     * @param token                                                                                                    //
     * @returns {*}                                                                                                    //
     */                                                                                                                //
    ufsDelete: function ufsDelete(fileId, storeName, token) {                                                          // 126
        check(fileId, String);                                                                                         // 127
        check(storeName, String);                                                                                      // 128
        check(token, String);                                                                                          // 129
                                                                                                                       //
        // Check store                                                                                                 //
        var store = UploadFS.getStore(storeName);                                                                      // 132
        if (!store) {                                                                                                  // 133
            throw new Meteor.Error('invalid-store', "Store not found");                                                // 134
        }                                                                                                              // 135
        // Ignore files that does not exist                                                                            //
        if (store.getCollection().find({ _id: fileId }).count() === 0) {                                               // 137
            return 1;                                                                                                  // 138
        }                                                                                                              // 139
        // Check token                                                                                                 //
        if (!store.checkToken(token, fileId)) {                                                                        // 141
            throw new Meteor.Error('invalid-token', "Token is not valid");                                             // 142
        }                                                                                                              // 143
        return store.getCollection().remove({ _id: fileId });                                                          // 144
    },                                                                                                                 // 145
                                                                                                                       //
    /**                                                                                                                //
     * Imports a file from the URL                                                                                     //
     * @param url                                                                                                      //
     * @param file                                                                                                     //
     * @param storeName                                                                                                //
     * @return {*}                                                                                                     //
     */                                                                                                                //
    ufsImportURL: function ufsImportURL(url, file, storeName) {                                                        // 154
        check(url, String);                                                                                            // 155
        check(file, Object);                                                                                           // 156
        check(storeName, String);                                                                                      // 157
                                                                                                                       //
        // Check URL                                                                                                   //
        if (typeof url !== 'string' || url.length <= 0) {                                                              // 160
            throw new Meteor.Error('invalid-url', "The url is not valid");                                             // 161
        }                                                                                                              // 162
        // Check file                                                                                                  //
        if ((typeof file === 'undefined' ? 'undefined' : _typeof(file)) !== 'object' || file === null) {               // 164
            throw new Meteor.Error('invalid-file', "The file is not valid");                                           // 165
        }                                                                                                              // 166
        // Check store                                                                                                 //
        var store = UploadFS.getStore(storeName);                                                                      // 168
        if (!store) {                                                                                                  // 169
            throw new Meteor.Error('invalid-store', 'The store does not exist');                                       // 170
        }                                                                                                              // 171
                                                                                                                       //
        // Extract file info                                                                                           //
        if (!file.name) {                                                                                              // 174
            file.name = url.replace(/\?.*$/, '').split('/').pop();                                                     // 175
        }                                                                                                              // 176
        if (file.name && !file.extension) {                                                                            // 177
            file.extension = file.name && file.name.substr((~-file.name.lastIndexOf('.') >>> 0) + 2).toLowerCase();    // 178
        }                                                                                                              // 179
        if (file.extension && !file.type) {                                                                            // 180
            // Assign file MIME type based on the extension                                                            //
            file.type = UploadFS.getMimeType(file.extension) || 'application/octet-stream';                            // 182
        }                                                                                                              // 183
        // Check if file is valid                                                                                      //
        if (store.getFilter() instanceof UploadFS.Filter) {                                                            // 185
            store.getFilter().check(file);                                                                             // 186
        }                                                                                                              // 187
                                                                                                                       //
        if (file.originalUrl) {                                                                                        // 189
            console.warn('ufs: The "originalUrl" attribute is automatically set when importing a file from a URL');    // 190
        }                                                                                                              // 191
                                                                                                                       //
        // Add original URL                                                                                            //
        file.originalUrl = url;                                                                                        // 194
                                                                                                                       //
        // Create the file                                                                                             //
        file.complete = false;                                                                                         // 197
        file.uploading = true;                                                                                         // 198
        file.progress = 0;                                                                                             // 199
        file._id = store.create(file);                                                                                 // 200
                                                                                                                       //
        var fut = new Future();                                                                                        // 202
        var proto = void 0;                                                                                            // 203
                                                                                                                       //
        // Detect protocol to use                                                                                      //
        if (/http:\/\//i.test(url)) {                                                                                  // 206
            proto = http;                                                                                              // 207
        } else if (/https:\/\//i.test(url)) {                                                                          // 208
            proto = https;                                                                                             // 209
        }                                                                                                              // 210
                                                                                                                       //
        this.unblock();                                                                                                // 212
                                                                                                                       //
        // Download file                                                                                               //
        proto.get(url, Meteor.bindEnvironment(function (res) {                                                         // 215
            // Save the file in the store                                                                              //
            store.write(res, file._id, function (err, file) {                                                          // 217
                if (err) {                                                                                             // 218
                    fut['throw'](err);                                                                                 // 219
                } else {                                                                                               // 220
                    fut['return'](file);                                                                               // 221
                }                                                                                                      // 222
            });                                                                                                        // 223
        })).on('error', function (err) {                                                                               // 224
            fut['throw'](err);                                                                                         // 225
        });                                                                                                            // 226
        return fut.wait();                                                                                             // 227
    },                                                                                                                 // 228
                                                                                                                       //
    /**                                                                                                                //
     * Marks the file uploading as stopped                                                                             //
     * @param fileId                                                                                                   //
     * @param storeName                                                                                                //
     * @param token                                                                                                    //
     * @returns {*}                                                                                                    //
     */                                                                                                                //
    ufsStop: function ufsStop(fileId, storeName, token) {                                                              // 237
        check(fileId, String);                                                                                         // 238
        check(storeName, String);                                                                                      // 239
        check(token, String);                                                                                          // 240
                                                                                                                       //
        // Check store                                                                                                 //
        var store = UploadFS.getStore(storeName);                                                                      // 243
        if (!store) {                                                                                                  // 244
            throw new Meteor.Error('invalid-store', "Store not found");                                                // 245
        }                                                                                                              // 246
        // Check file                                                                                                  //
        var file = store.getCollection().find({ _id: fileId }, { fields: { userId: 1 } });                             // 248
        if (!file) {                                                                                                   // 249
            throw new Meteor.Error('invalid-file', "File not found");                                                  // 250
        }                                                                                                              // 251
        // Check token                                                                                                 //
        if (!store.checkToken(token, fileId)) {                                                                        // 253
            throw new Meteor.Error('invalid-token', "Token is not valid");                                             // 254
        }                                                                                                              // 255
                                                                                                                       //
        return store.getCollection().update({ _id: fileId }, {                                                         // 257
            $set: { uploading: false }                                                                                 // 258
        });                                                                                                            // 257
    }                                                                                                                  // 260
});                                                                                                                    // 11
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-server.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/meteor","meteor/webapp",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/jalik_ufs/ufs-server.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var WebApp;module.import('meteor/webapp',{"WebApp":function(v){WebApp=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var domain = Npm.require('domain');                                                                                    // 5
var fs = Npm.require('fs');                                                                                            // 6
var http = Npm.require('http');                                                                                        // 7
var https = Npm.require('https');                                                                                      // 8
var mkdirp = Npm.require('mkdirp');                                                                                    // 9
var stream = Npm.require('stream');                                                                                    // 10
var URL = Npm.require('url');                                                                                          // 11
var zlib = Npm.require('zlib');                                                                                        // 12
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 15
    var path = UploadFS.config.tmpDir;                                                                                 // 16
    var mode = UploadFS.config.tmpDirPermissions;                                                                      // 17
                                                                                                                       //
    fs.stat(path, function (err) {                                                                                     // 19
        if (err) {                                                                                                     // 20
            // Create the temp directory                                                                               //
            mkdirp(path, { mode: mode }, function (err) {                                                              // 22
                if (err) {                                                                                             // 23
                    console.error('ufs: cannot create temp directory at "' + path + '" (' + err.message + ')');        // 24
                } else {                                                                                               // 25
                    console.log('ufs: temp directory created at "' + path + '"');                                      // 26
                }                                                                                                      // 27
            });                                                                                                        // 28
        } else {                                                                                                       // 29
            // Set directory permissions                                                                               //
            fs.chmod(path, mode, function (err) {                                                                      // 31
                err && console.error('ufs: cannot set temp directory permissions ' + mode + ' (' + err.message + ')');
            });                                                                                                        // 33
        }                                                                                                              // 34
    });                                                                                                                // 35
});                                                                                                                    // 36
                                                                                                                       //
// Create domain to handle errors                                                                                      //
// and possibly avoid server crashes.                                                                                  //
var d = domain.create();                                                                                               // 40
                                                                                                                       //
d.on('error', function (err) {                                                                                         // 42
    console.error('ufs: ' + err.message);                                                                              // 43
});                                                                                                                    // 44
                                                                                                                       //
// Listen HTTP requests to serve files                                                                                 //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 47
    // Quick check to see if request should be catch                                                                   //
    if (req.url.indexOf(UploadFS.config.storesPath) === -1) {                                                          // 49
        next();                                                                                                        // 50
        return;                                                                                                        // 51
    }                                                                                                                  // 52
                                                                                                                       //
    // Remove store path                                                                                               //
    var parsedUrl = URL.parse(req.url);                                                                                // 55
    var path = parsedUrl.pathname.substr(UploadFS.config.storesPath.length + 1);                                       // 56
                                                                                                                       //
    var allowCORS = function allowCORS() {                                                                             // 58
        // res.setHeader('Access-Control-Allow-Origin', req.headers.origin);                                           //
        res.setHeader("Access-Control-Allow-Methods", "POST");                                                         // 60
        res.setHeader("Access-Control-Allow-Origin", "*");                                                             // 61
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");                                                 // 62
    };                                                                                                                 // 63
                                                                                                                       //
    if (req.method === "OPTIONS") {                                                                                    // 65
        var regExp = new RegExp('^\/([^\/\?]+)\/([^\/\?]+)$');                                                         // 66
        var match = regExp.exec(path);                                                                                 // 67
                                                                                                                       //
        // Request is not valid                                                                                        //
        if (match === null) {                                                                                          // 70
            res.writeHead(400);                                                                                        // 71
            res.end();                                                                                                 // 72
            return;                                                                                                    // 73
        }                                                                                                              // 74
                                                                                                                       //
        // Get store                                                                                                   //
        var store = UploadFS.getStore(match[1]);                                                                       // 77
        if (!store) {                                                                                                  // 78
            res.writeHead(404);                                                                                        // 79
            res.end();                                                                                                 // 80
            return;                                                                                                    // 81
        }                                                                                                              // 82
                                                                                                                       //
        // If a store is found, go ahead and allow the origin                                                          //
        allowCORS();                                                                                                   // 85
                                                                                                                       //
        next();                                                                                                        // 87
    } else if (req.method === 'POST') {                                                                                // 88
        var _ret = function () {                                                                                       // 89
            // Get store                                                                                               //
            var regExp = new RegExp('^\/([^\/\?]+)\/([^\/\?]+)$');                                                     // 91
            var match = regExp.exec(path);                                                                             // 92
                                                                                                                       //
            // Request is not valid                                                                                    //
            if (match === null) {                                                                                      // 95
                res.writeHead(400);                                                                                    // 96
                res.end();                                                                                             // 97
                return {                                                                                               // 98
                    v: void 0                                                                                          // 98
                };                                                                                                     // 98
            }                                                                                                          // 99
                                                                                                                       //
            // Get store                                                                                               //
            var store = UploadFS.getStore(match[1]);                                                                   // 102
            if (!store) {                                                                                              // 103
                res.writeHead(404);                                                                                    // 104
                res.end();                                                                                             // 105
                return {                                                                                               // 106
                    v: void 0                                                                                          // 106
                };                                                                                                     // 106
            }                                                                                                          // 107
                                                                                                                       //
            // If a store is found, go ahead and allow the origin                                                      //
            allowCORS();                                                                                               // 110
                                                                                                                       //
            // Get file                                                                                                //
            var fileId = match[2];                                                                                     // 113
            if (store.getCollection().find({ _id: fileId }).count() === 0) {                                           // 114
                res.writeHead(404);                                                                                    // 115
                res.end();                                                                                             // 116
                return {                                                                                               // 117
                    v: void 0                                                                                          // 117
                };                                                                                                     // 117
            }                                                                                                          // 118
                                                                                                                       //
            var tmpFile = UploadFS.getTempFilePath(fileId);                                                            // 120
            var ws = fs.createWriteStream(tmpFile, { flags: 'a' });                                                    // 121
            var fields = { uploading: true };                                                                          // 122
            var progress = parseFloat(req.query.progress);                                                             // 123
            if (!isNaN(progress) && progress > 0) {                                                                    // 124
                fields.progress = Math.min(progress, 1);                                                               // 125
            }                                                                                                          // 126
                                                                                                                       //
            req.on('data', function (chunk) {                                                                          // 128
                ws.write(chunk);                                                                                       // 129
            });                                                                                                        // 130
            req.on('error', function (err) {                                                                           // 131
                res.writeHead(500);                                                                                    // 132
                res.end();                                                                                             // 133
            });                                                                                                        // 134
            req.on('end', Meteor.bindEnvironment(function () {                                                         // 135
                // Update completed state                                                                              //
                store.getCollection().update({ _id: fileId }, { $set: fields });                                       // 137
                ws.end();                                                                                              // 138
            }));                                                                                                       // 139
            ws.on('error', function (err) {                                                                            // 140
                console.error('ufs: cannot write chunk of file "' + fileId + '" (' + err.message + ')');               // 141
                fs.unlink(tmpFile, function (err) {                                                                    // 142
                    err && console.error('ufs: cannot delete temp file "' + tmpFile + '" (' + err.message + ')');      // 143
                });                                                                                                    // 144
                res.writeHead(500);                                                                                    // 145
                res.end();                                                                                             // 146
            });                                                                                                        // 147
            ws.on('finish', function () {                                                                              // 148
                res.writeHead(204, { "Content-Type": 'text/plain' });                                                  // 149
                res.end();                                                                                             // 150
            });                                                                                                        // 151
        }();                                                                                                           // 89
                                                                                                                       //
        if ((typeof _ret === 'undefined' ? 'undefined' : _typeof(_ret)) === "object") return _ret.v;                   // 89
    } else if (req.method == 'GET') {                                                                                  // 152
        var _ret2 = function () {                                                                                      // 153
            // Get store, file Id and file name                                                                        //
            var regExp = new RegExp('^\/([^\/\?]+)\/([^\/\?]+)(?:\/([^\/\?]+))?$');                                    // 155
            var match = regExp.exec(path);                                                                             // 156
                                                                                                                       //
            // Avoid 504 Gateway timeout error                                                                         //
            // if file is not handled by UploadFS.                                                                     //
            if (match === null) {                                                                                      // 160
                next();                                                                                                // 161
                return {                                                                                               // 162
                    v: void 0                                                                                          // 162
                };                                                                                                     // 162
            }                                                                                                          // 163
                                                                                                                       //
            // Get store                                                                                               //
            var storeName = match[1];                                                                                  // 166
            var store = UploadFS.getStore(storeName);                                                                  // 167
                                                                                                                       //
            if (!store) {                                                                                              // 169
                res.writeHead(404);                                                                                    // 170
                res.end();                                                                                             // 171
                return {                                                                                               // 172
                    v: void 0                                                                                          // 172
                };                                                                                                     // 172
            }                                                                                                          // 173
                                                                                                                       //
            if (store.onRead !== null && store.onRead !== undefined && typeof store.onRead !== 'function') {           // 175
                console.error('ufs: store "' + storeName + '" onRead is not a function');                              // 176
                res.writeHead(500);                                                                                    // 177
                res.end();                                                                                             // 178
                return {                                                                                               // 179
                    v: void 0                                                                                          // 179
                };                                                                                                     // 179
            }                                                                                                          // 180
                                                                                                                       //
            // Remove file extension from file Id                                                                      //
            var index = match[2].indexOf('.');                                                                         // 183
            var fileId = index !== -1 ? match[2].substr(0, index) : match[2];                                          // 184
                                                                                                                       //
            // Get file from database                                                                                  //
            var file = store.getCollection().findOne({ _id: fileId });                                                 // 187
            if (!file) {                                                                                               // 188
                res.writeHead(404);                                                                                    // 189
                res.end();                                                                                             // 190
                return {                                                                                               // 191
                    v: void 0                                                                                          // 191
                };                                                                                                     // 191
            }                                                                                                          // 192
                                                                                                                       //
            // Simulate read speed                                                                                     //
            if (UploadFS.config.simulateReadDelay) {                                                                   // 195
                Meteor._sleepForMs(UploadFS.config.simulateReadDelay);                                                 // 196
            }                                                                                                          // 197
                                                                                                                       //
            d.run(function () {                                                                                        // 199
                // Check if the file can be accessed                                                                   //
                if (store.onRead.call(store, fileId, file, req, res) !== false) {                                      // 201
                    var _ret3 = function () {                                                                          // 201
                        // Open the file stream                                                                        //
                        var rs = store.getReadStream(fileId, file);                                                    // 203
                        var ws = new stream.PassThrough();                                                             // 204
                                                                                                                       //
                        rs.on('error', Meteor.bindEnvironment(function (err) {                                         // 206
                            store.onReadError.call(store, err, fileId, file);                                          // 207
                            res.end();                                                                                 // 208
                        }));                                                                                           // 209
                        ws.on('error', Meteor.bindEnvironment(function (err) {                                         // 210
                            store.onReadError.call(store, err, fileId, file);                                          // 211
                            res.end();                                                                                 // 212
                        }));                                                                                           // 213
                        ws.on('close', function () {                                                                   // 214
                            // Close output stream at the end                                                          //
                            ws.emit('end');                                                                            // 216
                        });                                                                                            // 217
                                                                                                                       //
                        var headers = {                                                                                // 219
                            'Content-Type': file.type,                                                                 // 220
                            'Content-Length': file.size                                                                // 221
                        };                                                                                             // 219
                                                                                                                       //
                        // Transform stream                                                                            //
                        store.transformRead(rs, ws, fileId, file, req, headers);                                       // 225
                                                                                                                       //
                        // Parse headers                                                                               //
                        if (_typeof(req.headers) === 'object') {                                                       // 228
                            // Compress data using accept-encoding header                                              //
                            if (typeof req.headers['accept-encoding'] === 'string') {                                  // 230
                                var accept = req.headers['accept-encoding'];                                           // 231
                                                                                                                       //
                                // Compress with gzip                                                                  //
                                if (accept.match(/\bgzip\b/)) {                                                        // 234
                                    headers['Content-Encoding'] = 'gzip';                                              // 235
                                    delete headers['Content-Length'];                                                  // 236
                                    res.writeHead(200, headers);                                                       // 237
                                    ws.pipe(zlib.createGzip()).pipe(res);                                              // 238
                                    return {                                                                           // 239
                                        v: void 0                                                                      // 239
                                    };                                                                                 // 239
                                }                                                                                      // 240
                                // Compress with deflate                                                               //
                                else if (accept.match(/\bdeflate\b/)) {                                                // 234
                                        headers['Content-Encoding'] = 'deflate';                                       // 243
                                        delete headers['Content-Length'];                                              // 244
                                        res.writeHead(200, headers);                                                   // 245
                                        ws.pipe(zlib.createDeflate()).pipe(res);                                       // 246
                                        return {                                                                       // 247
                                            v: void 0                                                                  // 247
                                        };                                                                             // 247
                                    }                                                                                  // 248
                            }                                                                                          // 249
                        }                                                                                              // 250
                                                                                                                       //
                        // Send raw data                                                                               //
                        if (!headers['Content-Encoding']) {                                                            // 253
                            res.writeHead(200, headers);                                                               // 254
                            ws.pipe(res);                                                                              // 255
                        }                                                                                              // 256
                    }();                                                                                               // 201
                                                                                                                       //
                    if ((typeof _ret3 === 'undefined' ? 'undefined' : _typeof(_ret3)) === "object") return _ret3.v;    // 201
                } else {                                                                                               // 258
                    res.end();                                                                                         // 259
                }                                                                                                      // 260
            });                                                                                                        // 261
        }();                                                                                                           // 153
                                                                                                                       //
        if ((typeof _ret2 === 'undefined' ? 'undefined' : _typeof(_ret2)) === "object") return _ret2.v;                // 153
    } else {                                                                                                           // 262
        next();                                                                                                        // 263
    }                                                                                                                  // 264
});                                                                                                                    // 265
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/jalik:ufs/ufs.js");
require("./node_modules/meteor/jalik:ufs/ufs-mime.js");
require("./node_modules/meteor/jalik:ufs/ufs-utilities.js");
require("./node_modules/meteor/jalik:ufs/ufs-config.js");
require("./node_modules/meteor/jalik:ufs/ufs-filter.js");
require("./node_modules/meteor/jalik:ufs/ufs-store-permissions.js");
require("./node_modules/meteor/jalik:ufs/ufs-store.js");
require("./node_modules/meteor/jalik:ufs/ufs-methods.js");
require("./node_modules/meteor/jalik:ufs/ufs-server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['jalik:ufs'] = {}, {
  UploadFS: UploadFS
});

})();

//# sourceMappingURL=jalik_ufs.js.map
