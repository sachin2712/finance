var require = meteorInstall({"server":{"imports":{"fixtures":{"parties.js":["../../../both/collections/csvdata.collection",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/imports/fixtures/parties.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var csvdata_collection_1 = require('../../../both/collections/csvdata.collection');                               // 3
function loadParties() {                                                                                          // 5
    if (csvdata_collection_1.Productcategory.find().count() === 0) {                                              //
        var cateogry = [                                                                                          //
            {                                                                                                     //
                category: 'Dubstep-Free Zone'                                                                     //
            },                                                                                                    //
            {                                                                                                     //
                category: 'All dubstep all the time'                                                              //
            },                                                                                                    //
            {                                                                                                     //
                category: 'Savage lounging'                                                                       //
            }                                                                                                     //
        ];                                                                                                        //
        cateogry.forEach(function (party) { return csvdata_collection_1.Productcategory.insert(party); });        //
    }                                                                                                             //
}                                                                                                                 // 21
exports.loadParties = loadParties;                                                                                // 5
//# sourceMappingURL=parties.js.map                                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"categorycollection.js":["../../../both/collections/csvdata.collection","meteor/meteor",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/imports/publications/categorycollection.js                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var csvdata_collection_1 = require('../../../both/collections/csvdata.collection');                               // 1
var meteor_1 = require('meteor/meteor');                                                                          // 2
//export const Csvdata = new Mongo.Collection('csvdata');                                                         // 7
//export const Productcategory = new Mongo.Collection('Productcategory');                                         // 8
if (meteor_1.Meteor.isServer) {                                                                                   // 10
    meteor_1.Meteor.publish('csvdata', function () {                                                              //
        if (Roles.userIsInRole(this.userId, 'Accounts') || Roles.userIsInRole(this.userId, 'guest')) {            //
            var selector = { 'Assigned_user_id': this.userId };                                                   //
            //    $or: [                                                                                          //
            //      { 'Assigned_user_id': this.userId },                                                          //
            //      {                                                                                             //
            //        $and: [                                                                                     //
            //          { owner: this.userId },                                                                   //
            //          { owner: { $exists: true } }                                                              //
            //        ]                                                                                           //
            //      }                                                                                             //
            //    ]                                                                                               //
            //  };                                                                                                //
            return csvdata_collection_1.Csvdata.find(selector);                                                   //
        }                                                                                                         //
        else {                                                                                                    //
            return csvdata_collection_1.Csvdata.find();                                                           //
        }                                                                                                         //
    });                                                                                                           //
    meteor_1.Meteor.publish('Productcategory', function () {                                                      //
        return csvdata_collection_1.Productcategory.find();                                                       //
    });                                                                                                           //
    meteor_1.Meteor.publish("userData", function () {                                                             //
        if (Roles.userIsInRole(this.userId, 'admin')) {                                                           //
            return meteor_1.Meteor.users.find();                                                                  //
        }                                                                                                         //
        else {                                                                                                    //
            var selector = { '_id': this.userId };                                                                //
            return meteor_1.Meteor.users.find(selector);                                                          //
        }                                                                                                         //
    });                                                                                                           //
}                                                                                                                 // 56
//# sourceMappingURL=categorycollection.js.map                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"main.js":["./imports/fixtures/parties","meteor/meteor","./imports/publications/categorycollection",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var parties_1 = require('./imports/fixtures/parties');                                                            // 1
var meteor_1 = require('meteor/meteor');                                                                          // 2
require('./imports/publications/categorycollection');                                                             // 5
//import './imports/publications/cloudservice';                                                                   // 6
//import './imports/publications/images';                                                                         // 8
meteor_1.Meteor.startup(function () {                                                                             // 9
    // load initial Parties                                                                                       //
    parties_1.loadParties();                                                                                      //
});                                                                                                               // 14
//# sourceMappingURL=main.js.map                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"both":{"collections":{"csvdata.collection.js":["meteor/mongo","meteor/meteor","meteor/check","meteor/accounts-base",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/csvdata.collection.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var mongo_1 = require('meteor/mongo');                                                                            // 1
var meteor_1 = require('meteor/meteor');                                                                          // 2
var check_1 = require('meteor/check');                                                                            // 3
var accounts_base_1 = require('meteor/accounts-base');                                                            // 4
exports.Csvdata = new mongo_1.Mongo.Collection('csvdata');                                                        // 5
exports.Productcategory = new mongo_1.Mongo.Collection('Productcategory');                                        // 6
meteor_1.Meteor.users.allow({                                                                                     // 8
    insert: function () { return true; },                                                                         //
    update: function () { return true; },                                                                         //
    remove: function () { return true; }                                                                          //
});                                                                                                               //
exports.Productcategory.allow({                                                                                   // 13
    insert: function () {                                                                                         //
        if (Roles.userIsInRole(meteor_1.Meteor.userId(), 'admin')) {                                              //
            return true;                                                                                          //
        }                                                                                                         //
        else {                                                                                                    //
            return false;                                                                                         //
        }                                                                                                         //
    },                                                                                                            //
    update: function () {                                                                                         //
        if (Roles.userIsInRole(meteor_1.Meteor.userId(), 'admin')) {                                              //
            return true;                                                                                          //
        }                                                                                                         //
        else {                                                                                                    //
            return false;                                                                                         //
        }                                                                                                         //
    },                                                                                                            //
    remove: function () {                                                                                         //
        if (Roles.userIsInRole(meteor_1.Meteor.userId(), 'admin')) {                                              //
            return true;                                                                                          //
        }                                                                                                         //
        else {                                                                                                    //
            return false;                                                                                         //
        }                                                                                                         //
    }                                                                                                             //
});                                                                                                               //
exports.Csvdata.allow({                                                                                           // 39
    insert: function () { return true; },                                                                         //
    update: function () { return true; },                                                                         //
    remove: function () { return true; }                                                                          //
});                                                                                                               //
meteor_1.Meteor.methods({                                                                                         // 44
    'parseUpload': function (data) {                                                                              //
        check_1.check(data, Array);                                                                               //
        for (var i = 0; i < data.length; i++) {                                                                   //
            var item = data[i];                                                                                   //
            if (item["Transaction ID"] == '') {                                                                   //
                continue;                                                                                         //
            }                                                                                                     //
            var exists = void 0;                                                                                  //
            exists = exports.Csvdata.findOne({ "Transaction_ID": item["Transaction ID"] });                       //
            if (exists) {                                                                                         //
                exports.Csvdata.update({ "Transaction_ID": item["Transaction ID"] }, { $set: { "No": item["No."],
                        "Value_Date": item["Value Date"],                                                         //
                        "Txn_Posted_Date": new Date(item["Txn Posted Date"]),                                     //
                        "ChequeNo": item["ChequeNo."],                                                            //
                        "Description": item["Description"],                                                       //
                        "Cr/Dr": item["Cr/Dr"],                                                                   //
                        "Transaction_Amount(INR)": item["Transaction Amount(INR)"],                               //
                        "Available_Balance(INR)": item["Available Balance(INR)"] } });                            //
                console.log('transaction id :' + item["Transaction ID"] + 'with no:' + item["No."] + ' is updating document !!!! ');
            }                                                                                                     //
            else {                                                                                                //
                exports.Csvdata.insert({                                                                          //
                    "No": item["No."],                                                                            //
                    "Transaction_ID": item["Transaction ID"],                                                     //
                    "Value_Date": item["Value Date"],                                                             //
                    "Txn_Posted_Date": new Date(item["Txn Posted Date"]),                                         //
                    "ChequeNo": item["ChequeNo."],                                                                //
                    "Description": item["Description"],                                                           //
                    "Cr/Dr": item["Cr/Dr"],                                                                       //
                    "Transaction_Amount(INR)": item["Transaction Amount(INR)"],                                   //
                    "Available_Balance(INR)": item["Available Balance(INR)"],                                     //
                    "Assigned_category": "not assigned",                                                          //
                    "is_processed": 0,                                                                            //
                    "invoice_no": "not_assigned",                                                                 //
                    "invoice_description": "invoice_description",                                                 //
                    "Assigned_user_id": "not_assigned",                                                           //
                    "Assigned_username": "not_assigned"                                                           //
                });                                                                                               //
            }                                                                                                     //
        }                                                                                                         //
        return true;                                                                                              //
    },                                                                                                            //
    'addcategory': function (id, category) {                                                                      //
        check_1.check(id, String);                                                                                //
        check_1.check(category, String);                                                                          //
        exports.Csvdata.update({ "_id": id }, { $set: { "Assigned_category": category, "is_processed": 1 } });    //
    },                                                                                                            //
    'changecategory': function (id, category) {                                                                   //
        check_1.check(id, String);                                                                                //
        check_1.check(category, String);                                                                          //
        exports.Csvdata.update({ "_id": id }, { $set: { "Assigned_category": category } });                       //
    },                                                                                                            //
    'addInvoice': function (id, invoice_no, description, linkarray) {                                             //
        check_1.check(id, String);                                                                                //
        check_1.check(invoice_no, String);                                                                        //
        check_1.check(description, String);                                                                       //
        console.log(id + invoice_no + description);                                                               //
        console.log(linkarray);                                                                                   //
        exports.Csvdata.update({ "_id": id }, { $set: { "invoice_no": invoice_no, "invoice_description": description, "linktodrive": linkarray } });
    },                                                                                                            //
    'deleteinvoice': function (id) {                                                                              //
        check_1.check(id, String);                                                                                //
        exports.Csvdata.update({ "_id": id }, { $set: { "invoice_no": "not_assigned", "invoice_description": "invoice_description", "linktodrive": "notassigned" } });
    },                                                                                                            //
    'adduser': function (adduserinfo) {                                                                           //
        check_1.check(adduserinfo.username, String);                                                              //
        check_1.check(adduserinfo.email, String);                                                                 //
        check_1.check(adduserinfo.password, String);                                                              //
        console.log(adduserinfo);                                                                                 //
        if (meteor_1.Meteor.isServer) {                                                                           //
            if (Roles.userIsInRole(meteor_1.Meteor.userId(), 'admin')) {                                          //
                var userid = accounts_base_1.Accounts.createUser(adduserinfo);                                    //
                console.log(userid);                                                                              //
                Roles.addUsersToRoles(userid, [adduserinfo.profile.role]);                                        //
            }                                                                                                     //
            else {                                                                                                //
                throw new meteor_1.Meteor.Error(403, "Access denied");                                            //
            }                                                                                                     //
        }                                                                                                         //
    },                                                                                                            //
    'removeuser': function (user) {                                                                               //
        if (Roles.userIsInRole(meteor_1.Meteor.userId(), 'admin')) {                                              //
            check_1.check(user._id, String);                                                                      //
            meteor_1.Meteor.users.remove(user._id);                                                               //
        }                                                                                                         //
        else {                                                                                                    //
            throw new meteor_1.Meteor.Error(403, "Access denied");                                                //
        }                                                                                                         //
    },                                                                                                            //
    'changepasswordforce': function (userId, newPassword) {                                                       //
        //      check(id,String);                                                                                 //
        console.log(userId);                                                                                      //
        console.log(newPassword);                                                                                 //
        if (meteor_1.Meteor.isServer) {                                                                           //
            if (userId === meteor_1.Meteor.userId() || Roles.userIsInRole(meteor_1.Meteor.userId(), 'admin')) {   //
                accounts_base_1.Accounts.setPassword(userId, newPassword);                                        //
            }                                                                                                     //
            else {                                                                                                //
                throw new meteor_1.Meteor.Error(403, "Access denied");                                            //
            }                                                                                                     //
        }                                                                                                         //
    },                                                                                                            //
    'assigntransdoctouser': function (docid, userid, username) {                                                  //
        if (meteor_1.Meteor.isServer) {                                                                           //
            if (Roles.userIsInRole(meteor_1.Meteor.userId(), 'admin')) {                                          //
                exports.Csvdata.update({ "_id": docid }, { $set: { "Assigned_user_id": userid, "Assigned_username": username } });
            }                                                                                                     //
            else {                                                                                                //
                throw new meteor_1.Meteor.Error(403, "Access denied");                                            //
            }                                                                                                     //
        }                                                                                                         //
    }                                                                                                             //
});                                                                                                               //
//# sourceMappingURL=csvdata.collection.js.map                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},{"extensions":[".js",".json",".ts",".html",".less"]});
require("./both/collections/csvdata.collection.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
